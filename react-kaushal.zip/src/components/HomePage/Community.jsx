import React from 'react';

const Community = () => {
    return (
        <div id="community">
              <div class="community_text">Be part of the community that's transforming fashion one item at a time.</div>
          </div>
    );
};

export default Community;