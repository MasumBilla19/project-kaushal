import Routers from "./router/Routers";

function App() {
  return (
    <Routers />
  );
}

export default App;
